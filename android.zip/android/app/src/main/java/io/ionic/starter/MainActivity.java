package com.auctiva.auctionsniper;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
