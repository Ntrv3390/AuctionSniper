var t=class{constructor(s){this.dialogData=s,this.backdropClickToClose=!1,this.hardwareBackButtonClose=!0,this.showBackground=!0}};export{t as a};
