import{b as r}from"./chunk-AVPD2MGH.js";var t=r("Browser",{web:()=>import("./chunk-XFQJWT6D.js").then(e=>new e.BrowserWeb)});export{t as a};
