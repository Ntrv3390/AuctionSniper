import{a as E}from"./chunk-PNNX457U.js";import{b as p}from"./chunk-V55QAZZA.js";import{l as $}from"./chunk-CE665YR7.js";import{Sa as y,o as u,r as h}from"./chunk-P3OSX3L2.js";import{a as g,b as f,h as d}from"./chunk-B7O3QC5Z.js";var R=(()=>{let n=class n{constructor(e,s){this.ui=e,this.messageExtractor=s}handleError(e,s,a=!0,r=!1,i=!1){console.group(`\u26A0\uFE0F API Error${s?` (${s})`:""}`),console.error("Error Object:",e),console.error("Stringified:",this.stringifyErrorObject(e)),console.groupEnd();let t=this.messageExtractor.extractErrorMessage(e);return s&&(t.title=`${s} ${t.title}`),i?this.showErrorDialog(e,t,s):a&&!r?this.ui.showErrorSnackbar(t.message,t.title):r&&this.ui.alert(t.message,t.title),t}handleApiResult(e,s,a=!0,r=!1,i=!1){if(e.success){let m=this.messageExtractor.extractSuccessMessage(e);return m&&this.handleSuccess(m,s),null}console.group(`\u{1F4CB} API Result Error${s?` (${s})`:""}`),console.error("API Result:",e),console.error("Stringified Result:",this.stringifyErrorObject(e)),console.groupEnd();let t="Operation failed. Please try again.",l=s?`${s} Failed`:"Operation Failed";e.message&&(typeof e.message=="string"?t=e.message:e.message.MessageContent?t=e.message.MessageContent:e.message.message&&(t=e.message.message)),t==="Operation failed. Please try again."&&e.error&&(typeof e.error=="string"?t=e.error:e.error.message&&(t=e.error.message));let o={message:t,title:l,isRetryable:!0};return i?this.showErrorDialog(e,o,s):a&&!r?this.ui.showErrorSnackbar(o.message,o.title):r&&this.ui.alert(o.message,o.title),o}showDetailedApiResultAlert(e,s){if(e.success)return null;console.group(`\u{1F4CB} Detailed API Result Error${s?` (${s})`:""}`),console.error("API Result:",e),console.error("Stringified Result:",this.stringifyErrorObject(e)),console.groupEnd();let a="Operation failed. Please try again.",r=s?`${s} Failed`:"Operation Failed";e.message&&(typeof e.message=="string"?a=e.message:e.message.MessageContent?a=e.message.MessageContent:e.message.message&&(a=e.message.message));let i=a;i+=`

API Response Details:`,i+=`
\u2022 Success: ${e.success}`,e.authorized!==void 0&&(i+=`
\u2022 Authorized: ${e.authorized}`),e.message&&(i+=`
\u2022 Message Level: ${e.message.Level||"Unknown"}`,e.message.MessageContent&&(i+=`
\u2022 Message Content: ${e.message.MessageContent}`)),e.user&&(i+=`
\u2022 User Data: ${this.stringifyErrorObject(e.user)}`);let t=Object.keys(e).filter(o=>!["success","authorized","message","user"].includes(o));t.length>0&&(i+=`
\u2022 Other Properties: ${t.join(", ")}`,t.forEach(o=>{e[o]!==null&&e[o]!==void 0&&(i+=`
  - ${o}: ${this.stringifyErrorObject(e[o])}`)})),i+=`
\u2022 Time: ${new Date().toLocaleString()}`;let l={message:i,title:r,isRetryable:!0};return this.ui.alert(l.message,l.title),l}showDetailedErrorAlert(e,s){console.group(`\u{1F6A8} Detailed API Error${s?` (${s})`:""}`),console.error("Error Object:",e);let a=this.messageExtractor.extractErrorMessage(e);s&&(a.title=`${s} ${a.title}`);let r=a.message;if(e instanceof y){if(console.error("HTTP Status:",e.status),console.error("Status Text:",e.statusText),console.error("URL:",e.url),console.error("Headers:",e.headers),console.error("Error Body:",e.error),r+=`

Technical Details:`,r+=`
\u2022 Status Code: ${e.status}`,r+=`
\u2022 Status Text: ${e.statusText||"Unknown"}`,e.url&&(r+=`
\u2022 URL: ${e.url}`),e.error&&(r+=`
\u2022 Server Response: ${this.stringifyErrorObject(e.error)}`),e.headers){let i=e.headers.keys();i.length>0&&(r+=`
\u2022 Request Headers: ${i.join(", ")}`)}r+=`
\u2022 Time: ${new Date().toLocaleString()}`,a.isRetryable&&(r+=`

\u{1F4A1} This error may be temporary. Please try again.`)}else e.message?(r+=`

Error Details: ${e.message}`,r+=`
\u2022 Time: ${new Date().toLocaleString()}`):(r+=`

Error Object: ${this.stringifyErrorObject(e)}`,r+=`
\u2022 Time: ${new Date().toLocaleString()}`);return console.error("Stringified Error:",this.stringifyErrorObject(e)),console.groupEnd(),this.showErrorDialog(e,f(g({},a),{message:r}),s),f(g({},a),{message:r})}handleSuccess(e,s,a=5e3){let r=s?`${s} Successful`:"Success";this.ui.showSuccessSnackbar(e,r,a)}showLoading(e){this.ui.activityStart(e+"...")}hideLoading(){this.ui.activityStop()}showErrorDialog(e,s,a){return d(this,null,function*(){try{let r=this.stringifyErrorObject(e),i={title:s.title,message:s.message,errorDetails:r,isRetryable:s.isRetryable},t=new E(i);(yield this.ui.showDialog("ErrorDialogController",t))?.action==="retry"&&s.isRetryable&&console.log("Retry action requested for error:",e)}catch(r){console.error("Failed to show error dialog, falling back to alert:",r);try{this.ui.alert(s.message,s.title)}catch(i){console.error("Failed to show alert, falling back to console:",i),console.error(`${s.title}: ${s.message}`)}}})}stringifyErrorObject(e){if(e==null)return"null";if(typeof e=="string")return e;if(typeof e=="number"||typeof e=="boolean")return String(e);try{let s=new WeakSet,r=JSON.stringify(e,(i,t)=>{if(typeof t=="object"&&t!==null){if(s.has(t))return"[Circular Reference]";s.add(t)}return t},2);return r.length<200?r.replace(/[{}]/g,"").replace(/\"/g,"").replace(/,\s*/g,", ").trim():r}catch{try{return Object.prototype.toString.call(e)}catch{return"[Unable to stringify object]"}}}};n.\u0275fac=function(s){return new(s||n)(h($),h(p))},n.\u0275prov=u({token:n,factory:n.\u0275fac,providedIn:"root"});let c=n;return c})();export{R as a};
