// boot.service.ts
import { Injectable, ErrorHandler, Injector } from '@angular/core';
import { Platform } from '@ionic/angular';
import { Application } from './application.service';
import { RouteConfig } from './route-config';
import { HttpInterceptor } from 'src/app/services/HttpInterceptor';

@Injectable({
  providedIn: 'root'
})
export class BootService {
  private applicationInstance!: Application;

  constructor(
    private platform: Platform,
    private injector: Injector,
    private app: Application
  ) {}

  public async main(): Promise<void> {
    console.log('[INFO] Boot.main: Bootstrapping the application.', {
      buildTimestamp: (window as any).__buildVars?.buildTimestamp,
      commitShortSha: (window as any).__buildVars?.commitShortSha,
    });

    await this.angular_initialize();
    this.angular_configure();
  }

  private async angular_initialize(): Promise<void> {
    await this.platform.ready();
    this.applicationInstance = this.app;

    try {
      await this.applicationInstance.start();
    } catch (error) {
      console.error('[ERROR] Boot.angular_initialize: Exception when calling Application.start()', error);
    }
  }

  private angular_configure(): void {
    // Configure routes
    RouteConfig.setupRoutes();

    // Register HTTP interceptor globally
    const httpInterceptor = this.injector.get(HttpInterceptor);
    // In Angular, this is normally handled in AppModule's providers:
    // { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true }

    console.log('[INFO] Boot.angular_configure: Configuration complete.');
  }
}
