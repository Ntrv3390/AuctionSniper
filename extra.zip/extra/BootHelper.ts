// boot-helper.ts (Modern Angular)

import { Type, Provider } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import { NgModule } from '@angular/core';

// Assume these are imported from your app
import { Services } from '../services';
import { Directives } from '../directives';
import { Filters } from '../filters';
import { Controllers } from '../controllers';
import { CommonModule } from '@angular/common';

export namespace BootHelper {

    function construct<T>(constructor: Type<T>, args: any[]): T {
        return new constructor(...args);
      }
      
      export function registerServices(providers: any[]): void {
        Services.forEach((Service: any) => {
          if (Service.ID) {
            if (typeof Service.getFactory === 'function') {
              providers.push({ provide: Service.ID, useFactory: Service.getFactory() });
            } else {
              providers.push({ provide: Service.ID, useClass: Service });
            }
          }
        });
      }
      
      export function registerDirectives(declarations: any[]): void {
        Directives.forEach((Directive: any) => {
          if (Directive.ID) {
            declarations.push(Directive);
          }
        });
      }
      
      export function registerFilters(providers: any[]): void {
        Filters.forEach((Filter: any) => {
          if (Filter.ID) {
            providers.push({
              provide: Filter.ID,
              useFactory: (...deps: any[]) => {
                const instance = construct<any>(Filter, deps); // Cast to any or your Filter base type
                return (instance as { filter: (...args: any[]) => any }).filter.bind(instance);
              },
              deps: Filter.$inject || [],
            });
          }
        });
      }
      
      export function registerControllers(declarations: any[]): void {
        Controllers.forEach((Controller: any) => {
          if (Controller.ID) {
            declarations.push(Controller);
          }
        });
      }
      
      export function getElementDirectiveFactoryFunction(Directive: any): any {
        return {
          selector: Directive.selector || `[${Directive.ID}]`,
          template: Directive.template || '',
          templateUrl: Directive.templateUrl,
          providers: [],
          inputs: Directive.inputs,
          outputs: Directive.outputs,
          scope: Directive.scope,
          transclude: Directive.transclude,
          link: (scope: any, el: any, attrs: any, ctrl: any, transcludeFn: any) => {
            const instance = construct<any>(Directive, []); // Cast to any or custom Directive base class
            (instance as any).scope = scope;
            (instance as any).element = el;
            (instance as any).attributes = attrs;
            (instance as any).controller = ctrl;
            (instance as any).transclude = transcludeFn;
            scope.directive = instance;
            (instance as any).initialize?.();
            (instance as any).render?.();
          },
        };
      }
      
      
      export function getDirectiveFactoryParameters(Directive: any): any {
        return () => construct(Directive, []);
      }
      
      export function getFilterFactoryFunction(Filter: any): any {
        return (...args: any[]) => {
          const instance = construct<any>(Filter, args); // Cast to any or expected filter interface
          return (instance as { filter: (...args: any[]) => any }).filter.bind(instance);
        };
      }
}
