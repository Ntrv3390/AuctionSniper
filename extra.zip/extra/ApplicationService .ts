import { Injectable, Inject, NgZone, OnDestroy } from '@angular/core';
import { Platform, NavController } from '@ionic/angular';
import { Router, NavigationStart, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { App as CapacitorApp, AppState as CapAppState } from '@capacitor/app';
import { Keyboard } from '@capacitor/keyboard';
import { StatusBar, Style as StatusBarStyle } from '@capacitor/status-bar';
import moment from 'moment';

// Your app services (migrated Angular services)
import { Utilities } from 'src/app/services/Utilities';
import { UIService } from 'src/app/services/UI';
import { AuctionSniperApiService } from 'src/app/services/AuctionSniperApi';
import { PreferencesService } from 'src/app/services/Preferences';
import { ConfigurationService } from 'src/app/services/Configuration';
import { Logger } from 'src/app/services/Logger';
import { EbayService } from 'src/app/services/Ebay';
import { PlatformService } from 'src/app/services/Platform'; // renamed to avoid clashing with Ionic Platform
import { TrackerService } from 'src/app/services/Tracker';
import { NavigatorService } from 'src/app/services/Navigator';
import { PushNotificationsService } from 'src/app/services/PushNotifications';
import { DataSourceService } from 'src/app/services/DataSource';
import { ApiMessageManagerService } from 'src/app/services/ApiMessageManager';
import { FreeSnipesService } from 'src/app/services/FreeSnipes';
import { AppEvents, DialogConstants } from 'src/app/constants/constants';
// import { AppConfig } from '../services/app-config';

// If you had a typed namespace for Enums, import it (or replace with your real import)
import * as Enums from '../enums'; // adjust path as needed

// If you use a custom Window token, import it; otherwise use the native window with typeof
const _win = () => window as any;

@Injectable({ providedIn: 'root' })
export class ApplicationService implements OnDestroy {
  private readonly BACK_BUTTON_EVENT_PRIORITY = 999;
  private _isShowingPinPrompt = false;

  private subs = new Subscription();

  constructor(
    private ionicPlatform: Platform,
    private nav: NavController,
    private router: Router,
    private zone: NgZone,

    private utilities: Utilities,
    private ui: UIService,
    private api: AuctionSniperApiService,
    private preferences: PreferencesService,
    private configuration: ConfigurationService,
    private logger: Logger,
    private ebay: EbayService,
    private platformSvc: PlatformService,
    private tracker: TrackerService,
    private navigator: NavigatorService,
    private push: PushNotificationsService,
    private dataSource: DataSourceService,
    private messageManager: ApiMessageManagerService,
    private freeSnipes: FreeSnipesService,
  ) {}

  /**
   * Call this once at app startup (e.g., in AppComponent after `platform.ready()`).
   */
  async start(): Promise<void> {
    // Global unhandled error handler
    _win().onerror = (event: Event | string, source?: string, lineno?: number, colno?: number, error?: Error) =>
      this.window_onerror(event, source as any, lineno as any, colno as any, error);

    // Capacitor App state
    CapacitorApp.addListener('appStateChange', (state: CapAppState) => this.capacitor_appStateChange(state));

    // Ionic back button (Android)
    this.subs.add(
      this.ionicPlatform.backButton.subscribeWithPriority(
        this.BACK_BUTTON_EVENT_PRIORITY,
        (processNextHandler) => {
          // keep parity with old behavior
          this.ionic_backButton();
        }
      )
    );

    // Router events: replace $locationChangeStart + $ionicView.beforeEnter
    this.subs.add(
      this.router.events.subscribe(evt => {
        if (evt instanceof NavigationStart) {
          const newUrl = evt.url;
          // There's no "oldRoute" readily available; you can store last route if you need exact parity
          this.logger.debug('Application', 'angular_locationChangeStart', 'Angular navigation started.', {
            oldRoute: null,
            newRoute: newUrl
          });
        }
        if (evt instanceof NavigationEnd) {
          const stateName = evt.urlAfterRedirects || evt.url;
          // Track view and set Crashlytics string (through your plugin wrapper)
          this.ionicView_beforeEnter(stateName);
        }
      })
    );

    // Replace $rootScope.$on(...) with DOM CustomEvent listeners.
    // This matches the interceptor migration where we dispatch CustomEvents on `document`.
    this.addDocumentListener(AppEvents.HTTP_ERROR, (e: CustomEvent) => this.http_error(e.detail?.event, e.detail));
    this.addDocumentListener(AppEvents.HTTP_API_UNAUTHORIZED, (e: CustomEvent) => this.http_apiUnauthorized(e.detail?.event, e.detail));
    this.addDocumentListener(AppEvents.HTTP_API_MESSAGE_RECEIVED, (e: CustomEvent) => {
      const { event, message } = e.detail || {};
      this.http_apiMessageReceived(event, e.detail?.event, message);
    });
    this.addDocumentListener(AppEvents.APP_USER_LOGGED_IN, (e: CustomEvent) => this.app_userLoggedIn(e as any, e.detail));
    this.addDocumentListener(AppEvents.APP_USER_LOGGED_OUT, (e: CustomEvent) => this.app_userLoggedOut(e as any));
    this.addDocumentListener(AppEvents.APP_PUSH_NOTIFICATION_RECEIVED, (e: CustomEvent) => this.app_pushNotificationReceived(e as any, e.detail));

    // Expose all services for debugging (as before)
    this.utilities.exposeAllServices();

    // Ensure we have device/platform info
    try {
      await this.platformSvc.initialize();
    } catch (err) {
      console.error('Error calling Platform.initialize() from ApplicationService.start', err);
    }

    // Initialize logger
    this.logger.initialize();

    // Hydrate preferences
    try {
      await this.preferences.initialize();
    } catch (err) {
      this.logger.error('Application', 'start', 'Error initializing preferences.', err);
    }

    // Analytics
    this.tracker.initialize();

    // Status bar & keyboard
    try {
      await StatusBar.setStyle({ style: StatusBarStyle.Dark });
    } catch {}
    try {
      await Keyboard.setScroll({ isDisabled: true });
      await Keyboard.setAccessoryBarVisible({ isVisible: true });
    } catch {}

    // Production: set user for tracking
    if (!this.configuration.debug && this.preferences.isUserLoggedIn) {
      this.tracker.setUser(this.preferences.getUser());
    }

    // Crashlytics flags (via your wrapper)
    try {
      await this.platformSvc.sharedNative_crashlytics_setBoolValue({
        key: DialogConstants.CRASHLYTICS_DEBUG_KEY,
        boolValue: this.configuration.debug,
      });
      await this.platformSvc.sharedNative_crashlytics_setUserIdentifier({
        userIdentifier: this.preferences.userUid ? this.preferences.userUid.toString() : null,
      });
    } catch {}

    // Expose Enums + awaitOn globally (old `$rootScope` use-case)
    const enums: Record<string, any> = {};
    Object.keys(Enums).forEach(k => (enums[k] = (Enums as any)[k]));
    this.utilities.setValue(_win(), 'Enums', enums);
    this.utilities.setValue(_win(), 'awaitOn', (p: Promise<any>) => {
      p.catch((error: any) => this.angular_exceptionHandler(error, 'Unhandled promise rejection.'));
    });

    // Initialize message handlers & push notifications
    this.messageManager.initialize();
    this.push.initialize();

    // Hide splash screen (Capacitor v5+ hides automatically if configured; keep for parity if you still call it)
    try {
      await this.platformSvc.splashHide();
    } catch {}

    // Finish cold boot path
    await this.resume(true);
  }

  // --- Pause / Resume --------------------------------------------------------

  private pause(): void {
    if (!this._isShowingPinPrompt) {
      this.configuration.lastPausedAt = moment();
    }
  }

  private async resume(coldBoot: boolean): Promise<void> {
    if (!this.preferences.isUserLoggedIn) {
      // Equivalent of Navigator.performNavigation(null) to go to login
      this.navigator.performNavigation(null);
      return;
    }

    if (coldBoot) {
      // get PN token, then appLaunch
      try {
        const pnToken = await this.push.getToken();
        this.logger.debug('Application', 'resume', 'Push notification device token on resume: ' + pnToken);

        const launchParams = {
          ADID: null as string | null,
          PushNotificationDeviceToken: null as string | null
        };

        if (this.preferences.allowPushNotifications) {
          launchParams.PushNotificationDeviceToken = pnToken;
        }

        const result = await this.api.appLaunch(launchParams);

        if (!result.isConfirmed) {
          this.freeSnipes.showReminder();
        }

        if (result.success) {
          this.preferences.winsCount = result.WinsCount;
        }
      } catch (err) {
        // Non-blocking
      }
    }

    this._isShowingPinPrompt = true;
    await this.ui.showPinEntryAfterResume();
    this._isShowingPinPrompt = false;

    if (coldBoot) {
      // Ensure ebay token
      try {
        await this.ebay.ensureValidEbayToken(false, true);
      } catch {
        // User not tokenized or chose logout — bail out like old code
        return;
      }
    }

    if (this.preferences.isEbayTokenValid) {
      // Fetch watches/snipes in background
      this.dataSource.retrieveWatches('AllowStale' as any);
      this.dataSource.retrieveSnipes('Active' as any, 'AllowStale' as any);
    }

    await this.navigator.handleNavigationOnResume(coldBoot);
  }

  // --- Event bridges ---------------------------------------------------------

  private capacitor_appStateChange(state: CapAppState): void {
    if (state.isActive) {
      this.resume(false);
    } else {
      this.pause();
    }
  }

  private ionic_backButton(): void {
    // If you kept a controller-shaped concept in NavigatorService, this preserves behavior.
    const currentController = this.navigator.currentController as any;

    if (currentController?.viewModel?.searchResults?.length > 0 &&
        typeof currentController.clearSearch === 'function') {
      currentController.clearSearch();
      // No $rootScope.$apply in Angular — zone.run if UI bindings needed
      this.zone.run(() => {});
      return;
    }

    // In Angular, prefer Router history
    if (this.router.url !== '/tabs/blank') {
      this.nav.back();
    } else {
      // Exit app via Capacitor
      CapacitorApp.exitApp();
    }
  }

  private ionicView_beforeEnter(stateName: string): void {
    try {
      this.tracker.trackView(stateName);
    } catch {}
    try {
      this.platformSvc.sharedNative_crashlytics_setStringValue({
        key: DialogConstants.CRASHLYTICS_CURRENT_STATE_NAME_KEY,
        stringValue: stateName
      });
    } catch {}
  }

  private app_userLoggedIn(_event: any, user: any) {
    this.preferences.userUid = user.Id;
    this.preferences.userId = user.UserName;
    this.preferences.userEmail = user.Email;
    this.preferences.token = user.Key;
    this.preferences.allowPushNotifications = true;

    try {
      this.platformSvc.sharedNative_crashlytics_setUserIdentifier({
        userIdentifier: user.Id ? user.Id.toString() : null
      });
    } catch {}

    this.tracker.setUser(user);

    // Load account preferences (background)
    this.api.getAccountPreferences(true).then(result => {
      if (result.success) {
        this.preferences.setAccountPreferences(result.preferences);
      }
    });

    // Register device for push
    this.push.registerDevice(this.preferences.getUser()).catch(error => {
      this.logger.error('Application', 'app_userLoggedIn', 'Push notification device registration failed.', error);
    });
  }

  private app_userLoggedOut(_event: any): void {
    this.logoutUser('UserInitiated' as any);
  }

  private async app_pushNotificationReceived(_event: any, notification: any): Promise<void> {
    try {
      const navState = await this.push.handlePushNotification(notification, false);
      if (navState) {
        this.navigator.performNavigation(navState);
      }
    } catch (error) {
      this.logger.error('Application', 'app_pushNotificationReceived', 'Error handling push notification.', {
        notification,
        error
      });
    }
  }

  // --- HTTP events -----------------------------------------------------------

  private http_error(_event: any, response: any): void {
    let message: string | null = null;
    const config = response?.config || {};
    let suppressErrors = config.suppressErrors;

    if (response?.status <= 0) {
      if (this.platformSvc.hasInternetConnection) {
        message = 'Network connection interrupted; please try again later.';
        this.logger.warn('Application', 'http_error', 'HTTP status 0 error.', response);
      } else {
        message = 'Network connection unavailable.';
      }
      suppressErrors = false;
    } else if ((response.status === 401 || response.status === 403) && this.preferences.isUserLoggedIn) {
      suppressErrors = true;
      this.http_apiUnauthorized(_event, response);
    } else if (response.status >= 500) {
      message = 'Server error; please try again later.';
      suppressErrors = false;
      this.logger.error('Application', 'http_error', '500-level HTTP error.', response);
    }

    if (message && !suppressErrors) {
      if (message.indexOf('\n') === -1) {
        this.ui.showErrorSnackbar(message);
      } else {
        this.ui.alert(message);
      }
    }
  }

  private http_apiUnauthorized(_event: any, _response: any): void {
    this.ui.showInfoSnackbar('Your session has expired; please login again.');
    this.logoutUser('SessionExpired' as any);
    this.navigator.performNavigation(null);
  }

  private http_apiMessageReceived(_e: any, _response: any, message: any): void {
    if (!message || message.Level == null || !message.MessageContent) return;

    const handled = this.messageManager.handleMessage(message);
    if (!handled) {
      this.logger.info('Application', 'http_apiMessageReceived', 'Unhandled API message.', {
        message,
        httpConfig: _response?.config
      });
    }
  }

  // --- Error handlers --------------------------------------------------------

  private window_onerror(message: any, uri: string, lineNumber: number, columnNumber?: number, error?: Error): void {
    try {
      this.logger.error('Application', 'window_onerror', message, {
        uri,
        lineNumber,
        columnNumber,
        error
      });
    } catch {}

    try {
      this.ui.showErrorSnackbar('An error has occurred; please try again.');
      this.ui.activityStop();
    } catch (ex) {
      this.logger.warn('Application', 'window_onerror', 'Failed to notify user; falling back to alert().', ex);
      alert('An error has occurred; please try again.');
    }
  }

  public angular_exceptionHandler(exception: Error, cause: string): void {
    let message = exception?.message || 'An unknown error ocurred in an Angular event.';
    cause = cause || '[Unknown]';

    try {
      this.logger.error('Application', 'angular_exceptionHandler', message, { cause, exception });
    } catch {}

    try {
      this.ui.showErrorSnackbar('An error has occurred; please try again.');
      this.ui.activityStop();
    } catch (ex) {
      this.logger.warn('Application', 'angular_exceptionHandler', 'Failed to notify user; falling back to alert().', ex);
      alert('An error has occurred; please try again.');
    }
  }

  // --- Logout helper ---------------------------------------------------------

  private logoutUser(reason: any): void {
    if (reason !== 'SessionExpired') {
      this.push.unregisterDevice(this.preferences.getUser()).catch(error => {
        this.logger.error('Application', 'app_userLoggedOut', 'Push unregistration failed.', error);
      });
    }

    this.preferences.userUid = null;
    this.preferences.userId = null;
    this.preferences.userEmail = null;
    this.preferences.token = null;
    this.preferences.allowPushNotifications = false;
    this.preferences.winsCount = 0;
    this.preferences.pin = null;

    this.dataSource.clear();

    try {
      this.platformSvc.sharedNative_crashlytics_setUserIdentifier({ userIdentifier: null });
    } catch {}

    this.tracker.clearUser();
  }

  // --- Utilities -------------------------------------------------------------

  private addDocumentListener(eventName: string, handler: (e: CustomEvent) => void) {
    // ensure handler runs inside Angular zone for UI updates
    const wrapped = (e: Event) => this.zone.run(() => handler(e as CustomEvent));
    document.addEventListener(eventName, wrapped as any);
    this.subs.add({
      unsubscribe: () => document.removeEventListener(eventName, wrapped as any)
    });
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
