// Migrated AngularJS UI-Router types to Angular-compatible TypeScript
// These interfaces are for legacy support or use in migration wrappers

export interface IState {
    name?: string;
    template?: string | (() => string);
    templateUrl?: string | (() => string);
    templateProvider?: () => any;
    controller?: Function | string;
    controllerAs?: string;
    controllerProvider?: () => any;
    resolve?: Record<string, unknown>;
    url?: string;
    params?: Record<string, any>;
    views?: Record<string, any>;
    abstract?: boolean;
    onEnter?: Function | (string | Function)[];
    onExit?: Function | (string | Function)[];
    data?: any;
    reloadOnSearch?: boolean;
  }
  
  export interface IStateProvider {
    state(name: string, config: IState): IStateProvider;
    state(config: IState): IStateProvider;
    decorator(name?: string, decorator?: (state: IState, parent: () => any) => any): any;
  }
  
  export interface IUrlMatcher {
    concat(pattern: string): IUrlMatcher;
    exec(path: string, searchParams: Record<string, any>): Record<string, any>;
    parameters(): string[];
    format(values: Record<string, any>): string;
  }
  
  export interface IUrlMatcherFactory {
    compile(pattern: string): IUrlMatcher;
    isMatcher(o: any): boolean;
    type(name: string, definition: any, definitionFn?: any): any;
  }
  
  export interface IUrlRouterProvider {
    when(path: RegExp | string | IUrlMatcher, handler: Function | string | any[]): IUrlRouterProvider;
    otherwise(handler: Function | string | any[]): IUrlRouterProvider;
    rule(handler: Function | any[]): IUrlRouterProvider;
  }
  
  export interface IStateOptions {
    location?: boolean | string;
    inherit?: boolean;
    relative?: IState;
    notify?: boolean;
    reload?: boolean;
  }
  
  export interface IHrefOptions {
    lossy?: boolean;
    inherit?: boolean;
    relative?: IState;
    absolute?: boolean;
  }
  
  export interface IStateService {
    go(to: string, params?: Record<string, any>, options?: IStateOptions): Promise<any>;
    transitionTo(state: string, params?: Record<string, any>, options?: IStateOptions | boolean): void;
    includes(state: string, params?: Record<string, any>): boolean;
    is(state: string | IState, params?: Record<string, any>): boolean;
    href(state: string | IState, params?: Record<string, any>, options?: IHrefOptions): string;
    get(state?: string): IState | IState[];
    current: IState;
    params: Record<string, any>;
    reload(): void;
  }
  
  export interface IUrlRouterService {
    sync(): void;
  }
  
  export interface IUiViewScrollProvider {
    useAnchorScroll(): void;
  }
  